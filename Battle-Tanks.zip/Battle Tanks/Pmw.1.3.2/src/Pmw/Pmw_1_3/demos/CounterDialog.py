title = 'Pmw.CounterDialog demonstration'

# Import Pmw from this directory tree.
import sys
sys.path[:0] = ['../../..']

import string
from Tkinter import *
import Pmw

class Counter:
    def __init__(self, canvas):
	# Create the dialog to prompt for the number of times to ring the bell.
	self.dialog1 = Pmw.CounterDialog(canvas,
	    label_text = 'Power',
	    counter_labelpos = 'n',
	    entryfield_value = 2,
	    counter_datatype = 'numeric',
	    entryfield_validate =
		{'validator' : 'numeric', 'min' : 1, 'max' : 5},
	    defaultbutton = 'OK',
	    title = 'Power and Angle',
	    command = self.execute)
	self.dialog2 = Pmw.CounterDialog(canvas,
	    label_text = 'Angle',
	    counter_labelpos = 'n',
	    entryfield_value = 2,
	    counter_datatype = 'numeric',
	    entryfield_validate =
		{'validator' : 'numeric', 'min' : 1, 'max' : 5},
	    defaultbutton = 'OK',
	    title = 'Bell ringing', 
	    command = self.execute)
	
	
	#self.dialog.withdraw()
	#self.dialog.activate()
	# Create button to launch the dialog.
	#w = Tkinter.Button(parent, text = 'Show counter dialog',
	#        command = self.dialog.activate)
	#w.pack(padx = 8, pady = 8)

    def execute(self, result):
	#if result is None or result == 'Cancel':
	#    print 'Bell ringing cancelled'
	#    self.dialog.deactivate()
	#else:
	count = self.dialog1.get()
	#if not self.dialog.valid():
	#    print 'Invalid entry: "' + count + '"'
	#else:
	#    print 'Ringing the bell ' + count + ' times'
	#    for num in range(string.atoi(count)):
	#	if num != 0:
	#	    self.dialog.after(200)
	#	self.dialog.bell()
	#	#self.dialog.deactivate()
		
def redraw():
    canvas.create_rectangle(50,50,100,100)
    widget = Demo(canvas)
######################################################################

# Create demo in root window for testing.
def run():
    root = Tk()
    global canvas
    canvas = Canvas(root,width= 1200,height = 800)
    canvas.pack()
    #Pmw.initialise(root)
    #root.title(title)

    #exitButton = Tkinter.Button(root, text = 'Exit', command = root.destroy)
    #exitButton.pack(side = 'bottom')
    redraw()
    
    root.mainloop()
    
run()
